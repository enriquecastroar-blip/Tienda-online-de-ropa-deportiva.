/* CONFIGURACIÓN: reemplazá este número por tu WhatsApp con código de país, solo números.
   Paraguay: 595 + número, sin +, espacios ni guiones. Ejemplo ficticio: 595981000000 */
const WHATSAPP_NUMBER = "595984850384";
const productsData = [
{id:1,name:"Conjunto deportivo mujer",category:"Conjuntos",desc:"Top + calza · Consultar talles",price:180000,img:"https://images.unsplash.com/photo-1518310383802-640c2de311b2?auto=format&fit=crop&w=700&q=80",tag:"DESTACADO"},
{id:2,name:"Remera deportiva hombre",category:"Camisetas",desc:"Liviana · Consultar talles",price:95000,img:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=700&q=80",tag:""},
{id:3,name:"Short deportivo",category:"Gimnasio",desc:"Cómodo para entrenar",price:70000,img:"https://images.unsplash.com/photo-1591195853828-11db59a44f6b?auto=format&fit=crop&w=700&q=80",tag:""},
{id:4,name:"Conjunto deportivo infantil",category:"Infantil",desc:"Consultar edades y talles",price:140000,img:"https://images.unsplash.com/photo-1517466787929-bc90951d0974?auto=format&fit=crop&w=700&q=80",tag:""},
{id:5,name:"Leggings deportivos",category:"Gimnasio",desc:"Calce cómodo · Consultar colores",price:110000,img:"https://images.unsplash.com/photo-1506629905607-d9a9d4f6b3b5?auto=format&fit=crop&w=700&q=80",tag:""},
{id:6,name:"Camiseta deportiva",category:"Camisetas",desc:"Modelos y equipos a consultar",price:120000,img:"https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=700&q=80",tag:""}
];
let cart=[];let selectedCategory="Todos";
const money=n=>"Gs. "+n.toLocaleString("es-PY");
function setCategory(cat){selectedCategory=cat;renderProducts()}
function renderProducts(){
 const term=(document.getElementById('search')?.value||'').toLowerCase();
 const cats=["Todos",...new Set(productsData.map(p=>p.category))];
 document.getElementById('filters').innerHTML=cats.map(c=>`<button class="${selectedCategory===c?'active':''}" onclick="setCategory('${c}')">${c}</button>`).join('');
 const list=productsData.filter(p=>(selectedCategory==="Todos"||p.category===selectedCategory)&&(p.name+" "+p.category+" "+p.desc).toLowerCase().includes(term));
 document.getElementById('products').innerHTML=list.map(p=>`<article class="product"><div class="product-image" style="background-image:url('${p.img}')">${p.tag?`<span class="tag">${p.tag}</span>`:''}</div><div class="product-info"><h3>${p.name}</h3><p>${p.desc}</p><div class="price">${money(p.price)}</div><div class="product-actions"><button class="btn" onclick="addToCart(${p.id})">AGREGAR AL PEDIDO</button><button class="btn outline" onclick="quickOrder(${p.id})">CONSULTAR</button></div></div></article>`).join('')||'<p>No encontramos productos. Probá otra búsqueda.</p>';
}
function addToCart(id){cart.push(id);document.getElementById('cartCount').textContent=cart.length;const p=productsData.find(x=>x.id===id);alert(p.name+' se agregó al pedido.');}
function openCart(){document.getElementById('cartItems').innerHTML=cart.length?'<b>Tu pedido:</b><br>'+cart.map(id=>{let p=productsData.find(x=>x.id===id);return `${p.name} — ${money(p.price)}`}).join('<br>')+`<br><br><b>Total estimado: ${money(cart.reduce((s,id)=>s+productsData.find(p=>p.id===id).price,0))}</b>`:'Todavía no agregaste productos. Podés completar una consulta igualmente.';document.getElementById('modal').classList.add('open')}
function closeCart(){document.getElementById('modal').classList.remove('open')}
function sendText(text){if(!WHATSAPP_NUMBER || WHATSAPP_NUMBER.includes("REEMPLAZAR")){alert("Antes de usar los pedidos, abrí index.html y reemplazá WHATSAPP_NUMBER por el número de WhatsApp de la tienda.");return}window.open('https://wa.me/'+WHATSAPP_NUMBER+'?text='+encodeURIComponent(text),'_blank')}
function sendOrder(){let items=cart.map(id=>{let p=productsData.find(x=>x.id===id);return '- '+p.name+': '+money(p.price)}).join('\n')||'Todavía no seleccioné productos; quiero consultar el catálogo.';let total=cart.reduce((s,id)=>s+productsData.find(p=>p.id===id).price,0);let text='Hola, Solemi Store. Quiero hacer este pedido:\n'+items+(cart.length?'\nTotal estimado: '+money(total):'')+'\nNombre: '+document.getElementById('customerName').value+'\nZona: '+document.getElementById('customerArea').value+'\nEntrega: '+document.getElementById('delivery').value+'\nNotas: '+document.getElementById('customerNotes').value+'\n¿Me confirman disponibilidad, talles y costo de envío?';sendText(text)}
function quickOrder(id){let p=productsData.find(x=>x.id===id);sendText('Hola, Solemi Store. Quiero consultar por '+p.name+' ('+money(p.price)+'). ¿Qué talles, colores y disponibilidad tienen?')}
function contactWhatsApp(){sendText('Hola, Solemi Store. Quiero consultar por sus productos, talles y envíos.')}
document.getElementById('year').textContent=new Date().getFullYear();renderProducts();
